#include<bits/stdc++.h>
using namespace std;



int main() {
    string a, b;
    int s1[256] = {};
    int s2[256] = {};
    int ans = 0;
    cin >> a >> b;

    for(int i = 0; i < a.size(); i++) {
        s1[a[i]]++;
    }
    for(int i = 0; i < b.size(); i++) {
        s2[b[i]]++;
    }

    for(int i = 0; i < a.size(); i++) {
        if(s1[a[i]] > s2[a[i]]) {
            ans++;
            s1[a[i]]--;
        }
        else if(s1[a[i]] < s2[a[i]]) {cout << -1; return 0;}
    }
    cout << ans;
    return 0;
}
