#include<bits/stdc++.h>

using namespace std;

int main() {
    int n, m, X, Y;
    int a[100][100];
    cin >> n >> m;
    for (int j = 0; j < m; j++) {
        for (int i = 0; i < n; i++) {
            cin >> a[i][j];
        }
    }
    cin >> X >> Y;
    int k = 0;
    for (int j = 0; j < m; j++) {
        k = upper_bound(&a[0][j], &a[0][j] + n, Y) - lower_bound(&a[0][j], &a[0][j] + n, X);

    }
    cout << k;
    return 0;
}
