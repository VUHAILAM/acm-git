#include<bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int k, n;
    vector<int> a;
    cin >> n >> k;
    for (int i = 0; i < 2*n*k; i++) {
        int tam;
        cin >> tam;
        a.push_back(tam);
    }
    sort(a.begin(), a.end());
    cout << a[1] - a[0];
    return 0;
}
