#include<bits/stdc++.h>

using namespace std;

double S(double a) {
    return 3*a*a;
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    double h, w;
    cin >> h >> w;
    if (h <= w) {
        if (h <= w/3) cout << h;
        else {
            if (S(h/2) > S(w/3)) cout << h/2;
            else cout << w/3;
        }

    } else if (w < h) {
        if (w <= h/3) cout << w;
        else {
            if (S(h/3) > S(w/2)) cout << h/3;
            else cout << w/2;
        }
    }
   return 0;
}
