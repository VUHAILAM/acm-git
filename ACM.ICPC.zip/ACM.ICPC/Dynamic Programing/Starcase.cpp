#include<bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int n, k;
    int a[1003];
    int dp[1003];
    memset(dp, 0, sizeof(dp));
    cin >> n;
    a[0] = 0;
    a[n+1] = 0;
    for(int i = 1; i <= n; i++) {
        cin >> a[i];
    }

    cin >> k;

    for(int i = 1; i <= (n+1); i++) {
        if(i-k <= 0) {
            dp[i] = a[i] + *max_element(dp,dp+i);
        } else {
            dp[i] = a[i] + *max_element(dp+i-k, dp+i);
        }
    }
    cout << dp[n+1];
    return 0;
}
