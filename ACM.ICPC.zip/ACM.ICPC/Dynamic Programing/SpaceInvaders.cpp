#include<bits/stdc++.h>

using namespace std;



int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    //int a[101];
    int p, n;
    int res = 0;
    cin >> n >> p;
    for(int i = 0; i < n; i++) {
        int x;
        cin >> x;
        res+= x;
    }
    if(p != 1 && p != n) {
        res += min(p-1, n-p) + n-1;
    } else res += n-1;

    cout << res;
    return 0;
}


