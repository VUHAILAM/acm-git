#include<bits/stdc++.h>

using namespace std;

string s1;

int GetPoi1(int i) {
    while (s1[i-1] != ' ') {
        i--;
    }
    return i;
}

int GetPoi2(int i) {
    while (s1[i+1] != ' '){
        i++;
    }
    return i;
}
int main() {
    fflush(stdin);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int a, b;
    getline(cin, s1);
    cin >> a >> b;
    s1 = ' ' + s1 + ' ';
    for (int i = a; i <= b; i++) {
        string s2;
        int t = 1;
        while(t<s1.size()) {
            if (s1[t] != ' ') {
                t = GetPoi1(t);
                s2 += s1.substr(t, GetPoi2(t) - t + 1) + ' ';
            } else {
                t = t+1;
                s2 += s1.substr(t, GetPoi2(t) - t + 1) + ' ';
            }
            t = t + i;
        }
        cout << s2.size()-1 << "\n";
    }
    return 0;
}
