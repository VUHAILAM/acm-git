#include <bits/stdc++.h>

using namespace std;


int main() {
    int T, N, K;
    int j = 0;
    int b[101];
    cin >> T;
    j = 0;
    int s= T;
    while (T > 0) {
        int a[101], h;
        cin >> N >> K;
        h = 0;
        for (int i = 0; i < N; i++) {
            cin >> a[i];
            h += a[i]/K;
        }
        b[j] = h;
        T--;
        j++;
    }
    for (int x = 0; x < s; x++) {
        cout << b[x] << endl;
    }
    return 0;
}
