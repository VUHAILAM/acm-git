#include<bits/stdc++.h>
using namespace std;

string a, b;

int pass['z'+1] = { 0 };
int origin['z' + 1] = { 0 };

void solve() {
    memset(pass, 0, sizeof(pass));
    memset(origin, 0, sizeof(origin));
    cin >> a;
    cin >> b;

    for(int i = 0; i< b.size(); i++) origin[b[i]]++;

    deque<int> d;
    int res = 0;
    for(int i = 0; i < a.size() ; i++) {
           // cout << "CHAR : " << a[i] << endl;
        if (origin[a[i]]==0) {
            while (d.size()) {
                int tmp = d.front();
                d.pop_front();
                pass[tmp]--;
            }
            //cout << "NOT EXIST\n";
        } else {
            pass[a[i]]++;
            d.push_back(a[i]);
            while (pass[a[i]] > origin[a[i]]) {
                int tmp = d.front();
                d.pop_front();
                pass[tmp]--;
            }
            //cout << "DEC TO " << d.size() << endl;


        }
        res |= (d.size() == b.size());



    }
    cout << (res? "YES\n" : "NO\n");

}

int main() {
    int T;
    cin >> T;
    while (T--) solve();

}
