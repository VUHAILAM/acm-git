#include<bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    queue<char> check;
    string a, b;
    int dem ['z' + 1] = {};
    int tam ['z' + 1] = {};
    cin >> a >> b;
    for (int i = 0; i < b.size(); i++) {
        dem[b[i]]++;
    }
    for (int i = 0; i < a.size(); i++) {
        if (dem[a[i]] > 0) {
            if (tam[a[i]] < dem[a[i]]) {
                    check.push(a[i]);
                    tam[a[i]]++;
            } else {
                memset(tam, 0, sizeof(tam));
                while (!check.empty()) check.pop();
            }
            if (check.size() == b.size()) {
                cout << "YES" << "\n";
                return 0;
            }
        }else {
                memset(tam, 0, sizeof(tam));
                while(!check.empty()) {
                    check.pop();
                }
            }
    }
    cout << "NO" << "\n";
    return 0;
}
