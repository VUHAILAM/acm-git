#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e2+5;
int vote[maxn][maxn];
int cnt[maxn];
int c, v;

void solve() {
    memset(vote, 0, sizeof(vote));
    memset(cnt, 0, sizeof(cnt));
    cin >> c >> v;
    for(int i =0 ; i< v; i++)
        for(int j = 0; j < c; j++) {
            cin >> vote[i][j];
        }
    for(int i = 0; i < v; i++)
        cnt[vote[i][0]]++;

    int max1 = 1;
    for(int i = 1; i <= c; i++)
        if (cnt[max1] < cnt[i]) max1 = i;
    if (cnt[max1] * 2 > v) {
        cout << max1 << ' ' << " 1\n";
        return;
    }
    cnt[max1] = 0;
    int max2 = 1;
    for(int i = 1; i <= c; i++)
        if (cnt[max2] < cnt[i]) max2 = i;
    int v1, v2;
    v1 = v2 = 0;
    for(int i = 0; i < v; i++) {
        for(int j = 0; j < c; j++) {
            if (vote[i][j] == max1) {
                v1++;
                break;
            }
            if (vote[i][j] == max2) {
                v2++;
                break;
            }


        }
    }
    cout << ( v1 > v2? max1 : max2) << " 2\n";

}


int main() {
    int T;
    cin >> T;
    while (T--) solve();

}
