#include<bits/stdc++.h>

using namespace std;

int N, K, A, B, G[50000][50000],u ,v, Tmin;

int XET[50000];

void TIM(int u, int n) {

}

int main() {
    cin >> N >> K >> A >> B;
    for (int x = 1; x <= N; x++) {
        for (int y = 1; y <= N; y++) {
            G[x][y] = B;
            if (x == y) G[x][y] = 0;
        }
    }

    for (int i = 1; i <=k ; i++) {
        cin >> u >> v;
        G[u][v] = A;
        G[v][u] = A;
    }

    for (int i = 1; i <= n; i++) {
        XET[i] = 0;
    }

}
