#include<bits/stdc++.h>
#define f(i, a, b) for(int i = a; i <= b; i++)

using namespace std;

string a[4];

int main(){
    f(i, 0, 3)
        cin >> a[i];
    //exit(0);
    f(i, 1, 3)
        f(j, 1, 3){
            int res = 0;
            if (a[i][j] == '#') res++;
            if (a[i][j-1] == '#') res++;
            if (a[i-1][j] == '#') res++;
            if (a[i-1][j-1] == '#') res++;
            if (res != 2){
                cout << "YES"; exit(0);
            }
        }
    cout << "NO";
}
