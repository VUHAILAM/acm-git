#include<bits/stdc++.h>

using namespace std;


int main() {
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    vector<float> a;
    vector<float> b;
    bool check;
    int k, x1, x2;
    float atam, btam;
    cin >> k >> x1 >> x2;
    for (int i = 0; i < k; i++) {
        cin >> atam >> btam;
        a.push_back(atam);
        b.push_back(btam);
    }

    for (int i = 0; i < k-1; i++) {
        for(int j = i+1; j < k; j++) {
            float t = (-b[i]+b[j])/(a[i]-a[j]);
            if ((t < x2) && (t > x1)) {
                check = true;
                cout << "YES";
                return 0;
            }
        }
    }
    if (!check) cout << "NO";
    return 0;
}
