#include<bits/stdc++.h>
#define f(i, a, b) for(int i = a; i <= b; i++)

using namespace std;

const int N = trunc(1e5) + 100;

int n, p, tmp, cntr;
int edge[N], head[N], u[N], v[N], ok[N];
long long sl[N], r[N];

void LoadGraph(){
    cin >> n >> p;
    f(i, 1, p){
        cin >> u[i] >> v[i];
        u[i]++;
        v[i]++;
        head[u[i]]++;
        head[v[i]]++;
    }

    f(i, 2, n+1)
        head[i] += head[i-1];

    f(i, 1, p){
        edge[head[u[i]]] = v[i];
        edge[head[v[i]]] = u[i];
        head[u[i]]--;
        head[v[i]]--;
    }
}

void DFS(int x){
    f(i, head[x]+1, head[x+1])
        if (ok[edge[i]] == 0){
            tmp++;
            ok[edge[i]] = 1;
            DFS(edge[i]);
        }
}

void Solve(){
    f(i, 1, n){
        ok[i] = 0;
        sl[i] = 0;
    }
    long long res = 0;
    cntr = 0;
    f(i, 1, n)
        if (ok[i] == 0){
            tmp = 1;
            ok[i] = 1;
            DFS(i);
            sl[tmp]++;
        }
    //cout << sl[3] << " " << sl[4] << endl;
    cntr = 0;
    f(i, 1, n)
        if (sl[i] != 0){
            res += (sl[i] * (sl[i]-1) / 2 * i * i);
            cntr++;
            r[cntr] = i;
        }
    //cout << res << endl;
    f(i, 1, cntr)
        f(j, i+1, cntr)
            res += sl[r[i]] * r[i] * sl[r[j]] * r[j];
    cout << res;
}

int main(){
    LoadGraph();
    Solve();
}
