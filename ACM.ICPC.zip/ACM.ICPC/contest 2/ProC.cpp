#include<bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0);cin.tie(0);
    cout.tie(0);
    string a, b;
    set<string> str;
    cin >> a >> b;
    for (long i = a.size(); i >= 1; i--) {
        long t = 1;
        for (long j = b.size()-1; j >= 0; j--) {
            string c = a.substr(0,i) + b.substr(j,t);
            str.insert(c);
            t++;
        }
    }
    cout << str.size();
    return 0;
}
