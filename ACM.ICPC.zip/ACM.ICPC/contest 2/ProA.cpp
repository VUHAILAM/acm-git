#include <iostream>

using namespace std;

long long Sum1 (long long a) {
    long long S = 0;
    for (long long i = 1; i <= a; i++) {
        S = S + i;
    }
    return S;
}

long long Sum3 (long long a) {
    long long t = 2;
    long long k = 1;
    long long S = 0;
    while (k <= a) {
        S = S + t;
        t+=2;
        k+=1;
    }
    return S;
}

long long Sum2 (long long a) {
    long long t = 1;
    long long k = 1;
    long long S = 0;
    while (k <= a) {
        S = S + t;
        t+=2;
        k+=1;
    }
    return S;
}

int main() {
    int P, a[4][10001];
    long long S1, S2, S3;
    cin >> P;
    for (int y = 1; y <= P ; y++) {
        for (int x = 0; x < 2; x++) {
            if (x == 0) {
                cin >> y;
                a[x][y] = y;
            } else {
                cin >> a[x][y];
            }
        }
    }

    for (int y = 1; y <= P; y++) {
        cout << y <<' '<<Sum1(a[1][y])<<' '<<Sum2(a[1][y])<<' '<<Sum3(a[1][y]) << endl;
    }
    return 0;
}
