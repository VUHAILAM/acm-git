#include <bits/stdc++.h>

using namespace std;

#define pb push_back

string s;
string ns;

int main() {
    // freopen("inp.txt", "r", stdin);

    cin >> s;

    ns = "";
    bool shouldAdd = false;
    for (int i = 0; i < s.size(); i++) {
        if (s[i] != '+' && s[i] != '-') {
            if (shouldAdd && s[i - 1] != '-') {
                ns.pb('+');
                if (s[i] != '0') shouldAdd = false;
            }
            ns.pb(s[i]);
        }
        else {
            if (s[i] == '+') {
                shouldAdd = false;
            }
            else {
                shouldAdd = true;
            }
            ns.pb(s[i]);
        }
    }

    cout << ns;

    return 0;
}