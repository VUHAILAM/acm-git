#include<bits/stdc++.h>
#define f(i, a, b) for(int i = a; i <= b; i++)

using namespace std;

const int N = trunc(6e5);

int a[N], s[N];
int x, y, n, pos, res, tmp;
string st;

int BiSe(int u, int v){
    int dau = v, cuoi = n, giua;
    while (dau <= cuoi){
        giua = (dau + cuoi) / 2;
        if (s[giua] - s[v-1] + giua-v <= u) dau = giua + 1;
        else cuoi = giua - 1;
    }
    return(cuoi+1);
}

void Solve(){
    memset(s, 0, sizeof(s));
    f(i, 1, n)
        s[i] = s[i-1] + a[i];
    f(i, x, y){
        pos = 1;
        res = a[1];
        while (pos <= n){
            tmp = BiSe(i, pos);
            if (tmp > n) break;
            res += (a[tmp] + 1);
            pos = tmp;
        }
        cout << res << endl;
    }
}

int main(){
    n = 0;
    while (true){
        cin >> st;
        if (st[0] > 47 && st[0] < 58){
            //cout << st << endl; exit(0);
            x = 0;
            f(i, 0, st.length()-1){
                x *= 10;
                x += (st[i] - 48);
            }
            cin >> y;
            break;
        } else {
            n++;
            a[n] = st.length();
        }
    }
    //cout << x << " " << y << endl;f(i, 1, n)cout << a[i] << endl;
    Solve();
}
