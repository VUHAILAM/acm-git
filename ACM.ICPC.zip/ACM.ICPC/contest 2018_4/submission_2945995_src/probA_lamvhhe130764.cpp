#include<bits/stdc++.h>

using namespace std;

map<int, string> so;
map<string, int> acsii;

void cac_so() {
    acsii["xxxxxx...xx...xx...xx...xx...xxxxxx"] = 0;
    acsii["....x....x....x....x....x....x....x"] = 1;
    acsii["xxxxx....x....xxxxxxx....x....xxxxx"] = 2;
    acsii["xxxxx....x....xxxxxx....x....xxxxxx"] = 3;
    acsii["x...xx...xx...xxxxxx....x....x....x"] = 4;
    acsii["xxxxxx....x....xxxxx....x....xxxxxx"] = 5;
    acsii["xxxxxx....x....xxxxxx...xx...xxxxxx"] = 6;
    acsii["xxxxx....x....x....x....x....x....x"] = 7;
    acsii["xxxxxx...xx...xxxxxxx...xx...xxxxxx"] = 8;
    acsii["xxxxxx...xx...xxxxxx....x....xxxxxx"] = 9;
    acsii[".......x....x..xxxxx..x....x......."] = 10;
    so[0] = "xxxxxx...xx...xx...xx...xx...xxxxxx";
    so[1] = "....x....x....x....x....x....x....x";
    so[2] = "xxxxx....x....xxxxxxx....x....xxxxx";
    so[3] = "xxxxx....x....xxxxxx....x....xxxxxx";
    so[4] = "x...xx...xx...xxxxxx....x....x....x";
    so[5] = "xxxxxx....x....xxxxx....x....xxxxxx";
    so[6] = "xxxxxx....x....xxxxxx...xx...xxxxxx";
    so[7] = "xxxxx....x....x....x....x....x....x";
    so[8] = "xxxxxx...xx...xxxxxxx...xx...xxxxxx";
    so[9] = "xxxxxx...xx...xxxxxx....x....xxxxxx";
}

string get_num(string s[8], int poi) {
    string a = "";
    for(int i = 0; i < 7; i++) {
        a += s[i].substr(poi, 5);
    }
    return a;
}

void in_so(int x) {
        int j = 0;
        cout << so[x].substr(j, 5)  <<'.';
        j+=5;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int j;
    string s[8];
    string a = "";
    string b = "";
    for(int i = 0; i < 7; i++) {
        cin >> s[i];
    }
    cac_so();
    for(int i = 0; i < s[0].size(); i+=6) {
        string t = get_num(s, i);
        if(acsii[t] != 10) a+= to_string(acsii[t]);
        else {
            j = i;
            break;
        }
    }

    for(int i = j+6; i < s[0].size(); i+=6) {
        string t = get_num(s, i);
        b+= to_string(acsii[t]);
    }
    int sum = stoi(a) + stoi(b);
    string c = to_string(sum);
    int y = 0;
    for(int h = 0; h < 7; h++) {
        for(int i = 0; i < c.size(); i++) {
            int k = c[i] - '0';
            if(i != c.size()-1)
            cout << so[k].substr(y, 5)  <<'.';
            else cout << so[k].substr(y, 5);
        }
        cout << "\n";
        y+=5;
    }
    return 0;
}

