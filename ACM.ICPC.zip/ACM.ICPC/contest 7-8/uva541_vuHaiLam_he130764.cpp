#include<bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int n, k, l;
    int a[101][101];
    int r[101] = {0}, c[101] = {0};
    while(true) {
        cin >> n;
        if(n == 0) break;
        memset(c,0,sizeof(c));
        memset(r,0,sizeof(r));
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                cin >> a[i][j];
                r[i] += a[i][j];
                c[j] += a[i][j];
            }
        }

        int checkr = 0;
        int checkc = 0;
        for(int i = 0; i < n; i++) {
            if(r[i]%2 == 1) {
                checkr++;
                k = i;
            }
            if(c[i]%2 == 1) {
                checkc++;
                l = i;
            }
            if(checkr + checkc > 2) break;
        }
        if(checkr == 0 && checkc == 0) cout << "OK" <<endl;
        else if(checkr == 1 && checkc == 1 ) cout << "Change bit (" << k+1 << ',' << l+1 << ")" << endl;
        else if(checkc + checkr > 0) cout << "Corrupt" << endl;
    }
    return 0;
}
