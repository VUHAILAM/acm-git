#include<bits/stdc++.h>

using namespace std;

struct C {
    int value[30];
};

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int N, R;
    map<string, C> arr;
    map<string, int> dim;
    //map<string, int*> index;

    cin >> N >> R;

    while (N--) {
        //int C[30];
        struct C v;
       string s;
       int L[21], U[21];
       cin >> s;
       int B, si, d;
       cin >> B;
       cin >> si;
       cin >> d;

       v.value[d] = si;
       for(int i = 1; i <= d; i++) {
            cin >> L[i];
            cin >> U[i];
       }
       v.value[0] = B - v.value[d]*L[d];
       for (int i = d-1; i >= 1; i--) {
            v.value[i] = v.value[i+1]*(U[i+1]-L[i+1] +1);
            v.value[0]-= v.value[i]*L[i];
       }
        arr[s] = v;
        dim[s] = d;
        //cout << s << " " << arr[s].value[0] << "\n";

    }
        //cout << arr["TWO"].value[0] << "\n";
    while(R--) {
        string t;
        cin >> t;
        int ind[11];
        int d = dim[t];
        for(int i = 1; i <= d; i++) {
            cin >> ind[i];
        }

        int s = arr[t].value[0];
        for(int i = 1; i <= d; i++) {
            s+= arr[t].value[i]*ind[i];
        }
        cout << t << '[';
        for(int i = 1; i <= d; i++) {
            if(d == 1 || i == d)
            cout << ind[i];
            else {
                    cout << ind[i] << ", ";
            }
        }
        cout << ']' << " = " << s << "\n";

    }
    return 0;
}
