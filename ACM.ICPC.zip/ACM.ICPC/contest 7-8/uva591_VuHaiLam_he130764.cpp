#include<bits/stdc++.h>

using namespace std;



int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int n, s, Htb, ans;
    int k = 1;
    int h[51];
    cin >> n;
    while(n != 0) {

        s = 0;
        for(int i = 0; i < n; i++) {
            cin >> h[i];
            s+= h[i];
        }
        Htb = s/n;
        ans  = 0;
        for(int i = 0; i < n; i++) {
            if(h[i] > Htb) {
                ans += h[i] - Htb;
            }
        }
        cout << "Set #" << k <<"\n";
        cout << "The minimum number of moves is " << ans <<'.'<< "\n";
        cout << "\n";
        k++;
        cin >> n;
    }
    return 0;
}
