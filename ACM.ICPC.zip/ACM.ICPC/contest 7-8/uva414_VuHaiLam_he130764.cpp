#include<bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    while(true) {
        int n;
        cin >> n;
        if(n == 0) break;
        string s;
        //char s[50];
        //getchar();
        int a[15];
        int minb = 99999999;
        int l , r;
        for(int i = 0; i < n; i++) {
            cin.ignore();
            getline(cin, s);

            //gets(s);
            int k = 0;
            while(s[k] != '\0' && s[k] == 'X') {
                k++;
            }
            l = k;
            while(s[k] != '\0' && s[k] != 'X') k++;
            r = k;
            a[i] = r-l;
            minb = min(a[i], minb);
        }
        int ans = 0;
        for(int i = 0; i < n; i++) {
                ans += a[i]-minb;
        }
        cout << ans << endl;
    }

    return 0;
}
