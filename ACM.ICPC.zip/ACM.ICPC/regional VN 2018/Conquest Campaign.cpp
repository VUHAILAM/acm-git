#include<bits/stdc++.h>
using namespace std;


int a[103][103];
int main() {
    int r, c ,n;
    cin >> r >> c >> n;
    int check = 0;
    for(int i  = 0; i <= r+1; i++) {a[i][0] = 1; a[i][c+1] = 1;}
    for(int j = 0; j <= c+1; j++) {a[0][j] = 1; a[r+1][j] = 1;}
    for(int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        if(a[x][y] == 0) check++;
        a[x][y] = 1;
    }

    int ans = 1;
    while(check != r*c) {
        for(int i = 1; i <= r; i++) {
            for(int j = 1; j <= c; j++) {
                if(a[i][j] == 1) {
                    if(a[i-1][j] == 0) {
                        a[i-1][j] = 2;
                        check++;
                    }
                     if(a[i][j-1] == 0) {
                        a[i][j-1] = 2;
                        check++;
                    }
                     if(a[i+1][j] == 0) {
                        a[i+1][j] = 2;
                        check++;
                    }
                     if(a[i][j+1] == 0) {
                        a[i][j+1] = 2;
                        check++;
                    }
                }
            }
        }
        for(int i = 1; i <= r; i++) {
            for(int j = 1; j <= c; j++) {
                if(a[i][j] == 2) a[i][j] = 1;
            }
        }
        ans++;
    }
    cout << ans;
    return 0;
}
