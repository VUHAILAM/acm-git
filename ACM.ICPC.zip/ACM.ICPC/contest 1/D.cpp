#include<bits/stdc++.h>
using namespace std;

int k, pos;
vector<int> origin, dest;

void solve() {
    while (k--) {
        dest.clear();
        for(int i = 0; i < origin.size(); i+=2) {
            int cnt = origin[i];
            int no = origin[i+1];
            for(int j = 0; j < cnt; j++) dest.push_back(no);
        }
        origin = dest;
    }
    cout << origin[pos];
}


int main() {
    ios::sync_with_stdio(0);cin.tie(0);
    cout.tie(0);
    cin >> k >> pos;
    string digits;
    cin >> digits;
    for(int i = 0; i < digits.size(); i++) {
        origin.push_back(digits[i] - '0');
    }
    solve();

}
