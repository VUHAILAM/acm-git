#include<bits/stdc++.h>
using namespace std;

const int maxn = 1e4+10;

int p;

int odd[maxn] = { 0 } , even[maxn] = { 0 };

void initialize() {
    odd[0] = 0;
    even[0] = 0;
    int nowOdd, nowEven;
    nowOdd = 1;
    nowEven = 2;
    for(int i = 1 ; i <=maxn; i++) {
        odd[i] = nowOdd + odd[i-1];
        even[i] = nowEven + even[i-1];
        nowOdd += 2;
        nowEven += 2;
    }
}


int k;
void solve() {
    cin >> k >> p;
    cout << k << " ";
    cout << (p*(p+1))/2 << " " << odd[p] << " " << even[p] << '\n' ;


}

int main() {
    initialize();
    int T;
    cin >> T;
    while (T--) solve();

}
