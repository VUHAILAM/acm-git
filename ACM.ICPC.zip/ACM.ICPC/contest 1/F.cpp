#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll maxn = 2e9;


ll n;
ll pos[10] = { 0 };
int now;
string tmp = "";
int main() {
    pos[0] = 0;
    pos[1] = 1*26;
    pos[2] = 2*26*26 + pos[1];
    pos[3] = 3*26*26*26 + pos[2];
    pos[4] = 4*26*26*26*26 + pos[3];
    pos[5] = 5*26*26*26*26*26 + pos[4];
    pos[6] = 6*26*26*26*26*26*26 + pos[5];
    pos[7] = 7*26*26*26*26*26*26*26 + pos[6];
    cin >> n;
    for(int i = 0; i <=7; i++)
        if (n <= pos[i]) {
            now = i;
            break;
        }
    if (n==0) {
        cout << "A";
        return 0;
    }
    n-=pos[now-1];
    cout <<"NOW = " << now << " N " << n << endl;
    ll posInNum = n%now;
    int m = n/now;
    cout << m << endl;
    cout << posInNum << endl;
    for(int i = 0; i < now; i++) {
        cout << "N = " << n << endl;
        tmp = char('A' + m%26) + tmp;
        m/=26;
    }

    cout << tmp << endl;
    cout << tmp[posInNum];

}

