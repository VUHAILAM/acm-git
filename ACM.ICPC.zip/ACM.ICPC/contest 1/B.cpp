#include<bits/stdc++.h>
using namespace std;




void solve() {
    string origin;
    cin >> origin;
    while (1) {
        string query;
        cin >> query;
        if (query == "END")
            return;

        if (query == "I") {
            int pos;
            string str;
            cin >> str >> pos;
            origin.insert(pos, str);
        } else {
            int l, r;
            cin >> l >> r;
            for(int i = l; i <= r; i++)
                cout << origin[i];
            cout << '\n';
        }
    }

}


int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int T;
    cin >> T;
    while (T--)
        solve();
}
