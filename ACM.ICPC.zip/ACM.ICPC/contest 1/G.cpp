#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e6+5;
double s;
int n;
double a[maxn], minn[maxn], maxx[maxn];

double res = DBL_MIN;

int main() {
    cin >> s;
    //res = s;
    cin >> n;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    minn[0] = a[0];
    for(int i =1; i < n; i++)
        minn[i] = min(a[i], minn[i-1]);

    for(int i =1; i < n; i++) {
        double no = (s / minn[i-1]);
        double profit = no*a[i];
        res = max(res, profit);


    }

    cout << std::fixed << setprecision(2)<< res-s;


}
