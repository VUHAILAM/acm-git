#include<bits/stdc++.h>
using namespace std;



struct Node {
    int index;
    int val;
    int l, r;
};


struct Tree {
    vector<Node> node;
};

int n, k;
Tree tree[565];


bool cmp(Node a, Node b) {
    if (a.val == b.val) return a.index < b.index;
    return a.val < b.val;
}


Node make_node(int i, int j) {
    Node tmp;
    tmp.index = i;
    tmp.val = j;
    tmp.l = tmp.r = 0;
    return tmp;
}


void push(int order, int val) {
    if (tree[order].node.size()==1) tree[order].node.push_back(make_node(1,val));
    else {
        int this_index = 1;
        int pre_index = 0;
        while( this_index != 0) {
            pre_index = this_index;
            if (val < tree[order].node[this_index].val) this_index = tree[order].node[this_index].l;
            else this_index = tree[order].node[this_index].r;
        }
        this_index = tree[order].node.size();
        if (val < tree[order].node[pre_index].val) tree[order].node[pre_index].l = this_index;
        else tree[order].node[pre_index].r = this_index;
        tree[order].node.push_back(make_node(this_index, val));
        //cout << "PUSH " << val << " AT " << this_index << endl;
    }
}

void init_tree(int order, vector<int> data) {
    tree[order].node.push_back(make_node(0,0));
    for(int i = 0 ; i < data.size(); i++) push(order, data[i]);


}

void print_node(Node x) {
    cout << "INDEX " << x.index << " VAL " << x.val << " L  R " << x.l << ' ' << x.r <<endl;
}

vector<int> res[55];

void dfs(Tree tree, Node node, vector<int> &res) {

    if (node.l) dfs(tree, tree.node[node.l], res);
    if (node.r) dfs(tree, tree.node[node.r], res);
    res.push_back(node.val);

}



void init(int order, vector<int> data) {
    tree[order].node.clear();
    vector<Node> tmp;
    for(int i = 0 ; i < data.size(); i++) tmp.push_back(make_node(i, data[i]));
    sort(tmp.begin(), tmp.end(), cmp);
    for(int i = 0; i < tmp.size(); i++) data[tmp[i].index] = i;
    //for(int i = 0 ; i < data.size(); i++) cout << data[i]<< ' ' ;
    //cout << endl;
    init_tree(order, data);
    //for(int i = 1 ; i < tree[order].node.size(); i++) {
    //    print_node(tree[order].node[i]);
    //}
    dfs(tree[order], tree[order].node[1], res[order]);
    //for(int i = 0 ; i < res[order].size(); i++) cout << res[order][i] << ' ';
    //cout << endl;



}

int cmp(vector<int> a, vector<int> b) {
    for(int i = 0 ; i < a.size(); i++) if (a[i] != b[i]) return 0;

    return 1;
}


void print_vec(vector<int> a) {
    for(int i = 0 ; i < a.size(); i++) cout << a[i] << ' ';
    cout << endl;
}

int solve() {
    int ans = 0;
    //for(int i = 0 ; i < n; i++) print_vec(res[i]);
    for(int i = 0; i < n ; i++) {
        int d = 1;
        for(int j = 0; j < i; j++)
            if (cmp(res[i], res[j])) d = 0;
        ans+=d;
    }
    return ans;
}


int main() {
    //freopen("C.c", "r", stdin);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin >> n >> k;
    for(int i = 0 ; i < n; i++) {
        vector<int> data;
        for(int j = 0; j < k; j++) {
            int x;
            cin >> x;
            data.push_back(x);
        }
        init(i, data);
    }
    cout << solve();

}

