#include <bits/stdc++.h>

using namespace std;

#define pb push_back

int n, k;
int pos[51], a[21];
vector<int> arr;
map<vector<int>, int> mm;

int check(int p) {
    for (int i = 0; i < k; i++) {
        if (pos[i] == p) return i;
    }
    return -1;
}

int main() {
    // freopen("inp.txt", "r", stdin);

    cin >> n >> k;

    int ans = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[0];
        for (int j = 0; j < k; j++) pos[j] = -1;
        pos[0] = 1;
        arr.clear();
        arr.pb(1);
        for (int j = 1; j < k; j++) {
            cin >> a[j];
            int cur = 1;
            while (true) {
                int now = check(cur);
                if (!~now) {
                    arr.pb(cur);
                    pos[j] = cur;
                    break;
                }
                else {  
                    if (a[j] > a[now]) {
                        cur = cur * 2 + 1;
                    }
                    else {
                        cur = cur * 2;
                    }
                }
            }
        }
        sort(arr.begin(), arr.end());
        // for (int i = 0; i < arr.size(); i++) cout << arr[i] << ' ';
        // cout << endl;
        if (!mm.count(arr)) ans++;
        mm[arr] = 1;
    }

    cout << ans;

    return 0;
}